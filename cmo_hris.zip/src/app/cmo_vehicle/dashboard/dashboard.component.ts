import {Component, ViewChild} from '@angular/core';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class VehicleDashboard {
  title = 'CMO - Vehicle Management System';
  constructor() {

  }
}
