import { Component } from '@angular/core';

@Component({
  selector: 'app-search-of-pol-and-mro',
  templateUrl: './search-of-pol-and-mro.component.html',
  styleUrls: ['./search-of-pol-and-mro.component.scss']
})
export class SearchOfPolAndMroComponent {
  mro_vehicle:any = ['Transfered','Depotation','Not Transfered'];

}
