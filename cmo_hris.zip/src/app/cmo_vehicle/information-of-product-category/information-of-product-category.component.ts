import { Component } from '@angular/core';

@Component({
  selector: 'app-information-of-product-category',
  templateUrl: './information-of-product-category.component.html',
  styleUrls: ['./information-of-product-category.component.scss']
})
export class InformationOfProductCategoryComponent {

}
